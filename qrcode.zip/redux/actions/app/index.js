import appSlice from '../../reducers/app';
export default appSlice.actions;